package com.salesianos.apart2ej2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apart2ej2Application {

	public static void main(String[] args) {
		SpringApplication.run(Apart2ej2Application.class, args);
	}

}
