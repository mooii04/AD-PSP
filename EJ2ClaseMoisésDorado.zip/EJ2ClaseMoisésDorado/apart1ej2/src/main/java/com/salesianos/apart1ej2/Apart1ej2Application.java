package com.salesianos.apart1ej2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apart1ej2Application {

	public static void main(String[] args) {
		SpringApplication.run(Apart1ej2Application.class, args);
	}

}
