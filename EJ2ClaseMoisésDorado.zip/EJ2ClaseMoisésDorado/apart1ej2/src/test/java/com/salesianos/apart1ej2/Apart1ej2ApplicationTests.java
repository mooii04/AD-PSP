package com.salesianos.apart1ej2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Apart1ej2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
