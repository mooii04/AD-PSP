package com.example.monumento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonumentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MonumentoApplication.class, args);
	}

}
